# Simple C programs

1st sum: C program to find sum of squares of n natural numbers.

2nd sum : Swapping two numbers without using third variable

3rd sum: C program to find one's place digit of a number

4th sum: Converting a string from uppercase to lowercase

5th sum: Converting the temperature from fahrenhit to celsius

6th sum: Checking whether the given character is alphabet or not

7th sum: Checking whether leap year or not

8th sum: Checking whether the given char is vowel and alphabet or consonant and alphabet or not an alphabet

9th sum: Checking which number is nearest to 100 among two numbers taken as input

10th sum: Checking whether the given number is armstrong or not

11th sum: Findind reverse of a number

12th sum: Finding factorial of a number

13th sum: Checking whether number is prime or not

14th sum: Finding the sum of even integers between two numbers

15th sum: Finding natural numbers from 1 to n

16th sum: C program to convert a given number to words

17th sum: Finding GCD of a number

18th sum: Finding sum of digits of a number

19th sum: Sum of Series of a number

20th sum: Finding total number of digits of a number

21st sum: Checking whether the given number is strong number or not

22nd sum: Finding the fibonacci series of a number

23rd sum: Finding prime numbers between  any two numbers

24th sum: C program to generate multiplication table

25th sum : C program to print pascal's triangle
